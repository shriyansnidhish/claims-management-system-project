package com.cognizant.model;

public class PlanCodeModel {

	private String planCode;

	private String planDescription;

	private String coverage1;

	private String coverage2;

	private String coverage3;

	private String coverage4;

	private String coverage5;

	public String getPlanCode() {
		return planCode;
	}

	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	public String getPlanDescription() {
		return planDescription;
	}

	public void setPlanDescription(String planDescription) {
		this.planDescription = planDescription;
	}

	public String getCoverage1() {
		return coverage1;
	}

	public void setCoverage1(String coverage1) {
		this.coverage1 = coverage1;
	}

	public String getCoverage2() {
		return coverage2;
	}

	public void setCoverage2(String coverage2) {
		this.coverage2 = coverage2;
	}

	public String getCoverage3() {
		return coverage3;
	}

	public void setCoverage3(String coverage3) {
		this.coverage3 = coverage3;
	}

	public String getCoverage4() {
		return coverage4;
	}

	public void setCoverage4(String coverage4) {
		this.coverage4 = coverage4;
	}

	public String getCoverage5() {
		return coverage5;
	}

	public void setCoverage5(String coverage5) {
		this.coverage5 = coverage5;
	}

}
